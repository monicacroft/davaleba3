package com.example.group1FirebaseProject

data class User(val name : String ?= null,
                val url : String ?= null)
